﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support
{
    public static class LocatorClass
    {
        public const string Appointment = "btn-make-appointment";
        public const string validate = "//h2[contains(text(),'Login')]";
        public const string username = "txt-username";
        public const string password = "txt-password";
        public const string login = "btn-login";
        public const string LoginValidate = "//h2[contains(text(),'Make Appointment')]";
        public const string faculty = "combo_facility";
        public const string readmission = "chk_hospotal_readmission";
        public const string Healthcare = "radio_program_medicare";
        public const string Date = "txt_visit_date";
        public const string comment = "txt_comment";
        public const string bookappointment = "btn-book-appointment";
        public const string appointmentVarification = "//h2[contains(text(),'Appointment Confirmation')]";

    }
}
