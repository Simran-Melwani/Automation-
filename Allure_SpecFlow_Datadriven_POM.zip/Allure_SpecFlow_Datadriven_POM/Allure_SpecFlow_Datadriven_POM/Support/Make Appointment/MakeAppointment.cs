﻿using Allure_SpecFlow_Datadriven_POM.Support.Data;
using Allure_SpecFlow_Datadriven_POM.Support.Login;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support.Make_Appointment
{
    public class MakeAppointment:LoginClass
    {
        string comment = DataClass.comment;
        string appointmentverification = DataClass.appointmentverification;
        string Faculty = DataClass.Faculty;
        string Date = DataClass.Date;
        string text;

        public void facultyinput()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.faculty)).SendKeys(Faculty);
        }
        public void hospitalreadmission()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.readmission)).Click();
        }
        public void HealthCareRadio()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Healthcare)).Click();
        }
        public void Dateinput()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Date)).SendKeys(Date);
        }
        public void Comment()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.comment)).SendKeys(comment);
        }
        public void Book()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.bookappointment)).Click();
        }
        public void FinalValidate()
        {
            text = chromeDriver.FindElement(By.XPath(LocatorClass.appointmentVarification)).Text;
            Assert.AreEqual(text, appointmentverification);
        }

    }
}
