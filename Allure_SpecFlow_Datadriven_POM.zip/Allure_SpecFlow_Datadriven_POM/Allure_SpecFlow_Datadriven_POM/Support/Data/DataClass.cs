﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support.Data
{
    public static class DataClass
    {
        public static readonly string username;
        public static readonly string password;
        public static readonly string comment;
        public static readonly string validate;
        public static readonly string LoginValidate;
        public static readonly string url;
        public static readonly string appointmentverification;
        public static readonly string Faculty;
        public static readonly string Date;
        static DataClass()
        {
            JObject jsonData = JObject.Parse(File.ReadAllText(@"C:\Users\simra\source\repos\Allure_SpecFlow_Datadriven_POM\Allure_SpecFlow_Datadriven_POM\Support\Data\data.json"));
            username = jsonData["username"].ToString();
            password = jsonData["password"].ToString();
            comment = jsonData["comment"].ToString();
            validate = jsonData["validate"].ToString();
            LoginValidate = jsonData["LoginValidate"].ToString();
            url = jsonData["url"].ToString();
            appointmentverification = jsonData["appointmentverification"].ToString();
            Faculty = jsonData["Faculty"].ToString();
            Date = jsonData["Date"].ToString();
        }
    }

}
