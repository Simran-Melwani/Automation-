﻿using Allure_SpecFlow_Datadriven_POM.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support.Appointment_1st_Page_
{
    public class AppoitmentClass:BaseClass
    {
        string text;
        string validate = DataClass.validate;
        public void Appointment()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Appointment)).Click();
        }
        public void Apointment_validate()
        {
            text = chromeDriver.FindElement(By.XPath(LocatorClass.validate)).Text;
            Assert.AreEqual(text, validate);

        }

    }
}
