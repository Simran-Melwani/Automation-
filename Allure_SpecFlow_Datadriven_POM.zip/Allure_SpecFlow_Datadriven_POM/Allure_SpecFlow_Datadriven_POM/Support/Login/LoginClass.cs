﻿using Allure_SpecFlow_Datadriven_POM.Support.Appointment_1st_Page_;
using Allure_SpecFlow_Datadriven_POM.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support.Login
{
    public class LoginClass: AppoitmentClass
    {
        string username = DataClass.username;
        string password = DataClass.password;
        string loginvalidate = DataClass.LoginValidate;
        string text;
        public void login_username()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.username)).SendKeys(username);
        }
        public void login_password()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.password)).SendKeys(password);
        }
        public void loginclick()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.login)).Click();
        }
        public void login_validate()
        {
            text = chromeDriver.FindElement(By.XPath(LocatorClass.LoginValidate)).Text;
            Assert.AreEqual(text, loginvalidate);
        }
    }

}
