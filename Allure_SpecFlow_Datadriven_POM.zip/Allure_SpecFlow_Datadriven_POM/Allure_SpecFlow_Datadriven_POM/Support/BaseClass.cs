﻿using Allure_SpecFlow_Datadriven_POM.Support.Data;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allure_SpecFlow_Datadriven_POM.Support
{
    public class BaseClass
    {
        string url = DataClass.url;

        public static ChromeDriver chromeDriver;
        public void BrowserIntialize()
        {
            chromeDriver = new ChromeDriver();
        }
        public void openURL()
        {

            chromeDriver.Manage().Window.Maximize();
            chromeDriver.Navigate().GoToUrl(url);
        }
        public void DisposeDriver()
        {
            chromeDriver.Close();
        }
    }
}
